document.getElementById("glitch_id").onclick = function() {
	var IdClassToChange =  document.getElementById('glitch_id').className

    if (IdClassToChange== "glitch") {
    	document.getElementById('glitch_id').classList.remove("glitch");
    	document.getElementById('glitch_id').classList.add("no_glitch");
 	}else if (IdClassToChange== "no_glitch"){
 		document.getElementById('glitch_id').classList.remove("no_glitch");
    	document.getElementById('glitch_id').classList.add("glitch");
 	}


    
}


document.getElementById("website1_id").onclick = function() {
	window.open("http://cathypellet-lamaisondebeaute.fr/");
}

document.getElementById("website2_id").onclick = function() {
	window.open("");
}

document.getElementById("spec_down_id").onclick = function() {
	window.open("");
}



document.getElementById("android1_id").onclick = function() {
    document.getElementById("android1_id_popup").style.display = "block";
}
document.getElementById("android_close_id").onclick = function() {
    document.getElementById("android1_id_popup").style.display = "none";
}



document.getElementById("php1_id").onclick = function() {
    document.getElementById("php1_id_popup").style.display = "block";
}
document.getElementById("php_close_id").onclick = function() {
    document.getElementById("php1_id_popup").style.display = "none";
}


/*document.getElementById("proc1_id").onclick = function() {
    document.getElementById("proc1_id_popup").style.display = "block";
}
document.getElementById("proc_close_id").onclick = function() {
    document.getElementById("proc1_id_popup").style.display = "none";
}
*/

document.getElementById("purebasic1_id").onclick = function() {
    document.getElementById("purebasic1_id_popup").style.display = "block";
}
document.getElementById("purebasic_close_id").onclick = function() {
    document.getElementById("purebasic1_id_popup").style.display = "none";
}


document.getElementById("python1_id").onclick = function() {
    document.getElementById("python1_id_popup").style.display = "block";
}
document.getElementById("python1_close_id").onclick = function() {
    document.getElementById("python1_id_popup").style.display = "none";
}

document.getElementById("python2_id").onclick = function() {
    document.getElementById("python2_id_popup").style.display = "block";
}
document.getElementById("python2_close_id").onclick = function() {
    document.getElementById("python2_id_popup").style.display = "none";
}

document.getElementById("python3_id").onclick = function() {
    document.getElementById("python3_id_popup").style.display = "block";
}
document.getElementById("python3_close_id").onclick = function() {
    document.getElementById("python3_id_popup").style.display = "none";
}

document.getElementById("python4_id").onclick = function() {
    document.getElementById("python4_id_popup").style.display = "block";
}
document.getElementById("python4_close_id").onclick = function() {
    document.getElementById("python4_id_popup").style.display = "none";
}

document.getElementById("python5_id").onclick = function() {
    document.getElementById("python5_id_popup").style.display = "block";
}
document.getElementById("python5_close_id").onclick = function() {
    document.getElementById("python5_id_popup").style.display = "none";
}




document.getElementById("rasp1_id").onclick = function() {
    document.getElementById("rasp1_id_popup").style.display = "block";
}
document.getElementById("rasp1_close_id").onclick = function() {
    document.getElementById("rasp1_id_popup").style.display = "none";
}

document.getElementById("rasp2_id").onclick = function() {
    document.getElementById("rasp2_id_popup").style.display = "block";
}
document.getElementById("rasp2_close_id").onclick = function() {
    document.getElementById("rasp2_id_popup").style.display = "none";
}

document.getElementById("rasp3_id").onclick = function() {
    document.getElementById("rasp3_id_popup").style.display = "block";
}
document.getElementById("rasp3_close_id").onclick = function() {
    document.getElementById("rasp3_id_popup").style.display = "none";
}

document.getElementById("rasp4_id").onclick = function() {
    document.getElementById("rasp4_id_popup").style.display = "block";
}
document.getElementById("rasp4_close_id").onclick = function() {
    document.getElementById("rasp4_id_popup").style.display = "none";
}

document.getElementById("rasp5_id").onclick = function() {
    document.getElementById("rasp5_id_popup").style.display = "block";
}
document.getElementById("rasp5_close_id").onclick = function() {
    document.getElementById("rasp5_id_popup").style.display = "none";
}

