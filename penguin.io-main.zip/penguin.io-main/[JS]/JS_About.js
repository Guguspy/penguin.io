document.getElementById("title_INFO_id").onclick = function() {
    document.querySelector('#timeline_id').scrollIntoView({behavior: 'smooth'});
}